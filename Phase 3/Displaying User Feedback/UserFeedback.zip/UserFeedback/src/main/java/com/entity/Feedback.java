package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="feedback")
public class Feedback {
	@Override
	public String toString() {
		return "Feedback [id=" + id + ", name=" + name + ", phase=" + phase + ", email=" + email
				+ ", review=" + review + "]";
	}

	@Id @GeneratedValue
	private int id;
	private String name;
	private String phase;
	private String email;
	private String review;
	
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Feedback(String name, String phase, String email ,String review) {
		super();
		this.name = name;
		this.phase = phase;
		this.email= email;
		this.review = review;
	}
	
	
}
