package com.user.info;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<User, Long> {
	
	@Query("SELECT p FROM User p WHERE CONCAT(p.id, p.name, p.email, p.location, p.contact) LIKE %?1%")
	public List<User> search(String keyword);
}
