package com.example.authenticationspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
